package wy;

import java.util.ArrayList;
public class ClassRef {
    private String mClassName;
    private ArrayList<FieldRef> mFieldRefs;
    private ArrayList<MethodRef> mMethodRefs;
    /**
     * Initializes a new class reference.
     */
    public ClassRef(String className) {
        mClassName = className;
        mFieldRefs = new ArrayList<FieldRef>();
        mMethodRefs = new ArrayList<MethodRef>();
    }
    /**
     * Adds the field to the field list.
     */
    public void addField(FieldRef fref) {
        mFieldRefs.add(fref);
    }
    /**
     * Returns the field list as an array.
     */
    public FieldRef[] getFieldArray() {
        return mFieldRefs.toArray(new FieldRef[mFieldRefs.size()]);
    }
    /**
     * Adds the method to the method list.
     */
    public void addMethod(MethodRef mref) {
        mMethodRefs.add(mref);
    }
    /**
     * Returns the method list as an array.
     */
    public MethodRef[] getMethodArray() {
        return mMethodRefs.toArray(new MethodRef[mMethodRefs.size()]);
    }
    /**
     * Gets the class name.
     */
    public String getName() {
        return mClassName;
    }
}

