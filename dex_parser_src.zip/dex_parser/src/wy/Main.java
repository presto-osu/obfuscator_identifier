package wy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String path = args[0];
		 String output = args[1];
		 String tag = args[2];
		if (path.endsWith(".apk")) {
			Set<String> allFiles = new HashSet<String>();
			Set<String> allStringConstant = new HashSet<String>();
			Set<String> allClsName = new HashSet<String>();
			Set<String> allMethodName = new HashSet<String>();
			Set<String> allFieldName = new HashSet<String>();
			Set<String> allPkgName = new HashSet<String>();
			Set<String> allExternalClsName = new HashSet<String>();
			Set<String> allExternalMethodName = new HashSet<String>();
			Set<String> allExternalFieldName = new HashSet<String>();
			Set<String> allExternalPkgName = new HashSet<String>();
			Set<String> allClsSig = new HashSet<String>();
			Set<String> allExternalClsSig = new HashSet<String>();
			List<String> l = unzip(path, allFiles);
			long total_classes = 0;
			long total_dexes_size = 0;
			for (String s : l) {
				File f = new File(s);
				int class_num = analyze(s, allStringConstant, allClsName, allMethodName, 
						allFieldName, allPkgName,
						allClsSig, allExternalMethodName, allExternalFieldName,
						allExternalClsName, allExternalPkgName,allExternalClsSig);
				if (class_num == 0) {
					continue;
				}
				total_dexes_size += f.length();
				total_classes += class_num;

				// System.out.println(s);
				try {
					Files.delete(Paths.get(s));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				PrintWriter fo = new PrintWriter(output);
				fo.write(tag);
				fo.write('\n');
				fo.write(Paths.get(path).getFileName().toString());
				fo.write('\n');
				fo.write("" + total_classes);
				fo.write('\n');
				fo.write("" + total_dexes_size);
				fo.write('\n');
				fo.write("----------------fileName----------------");
				fo.write('\n');
				for (String s : allFiles) {
					fo.write(Paths.get(s).getFileName().toString());
					fo.write('\n');
				}
				fo.write("----------------string----------------");
				fo.write('\n');
				for (String s : allStringConstant) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------pkgName----------------");
				fo.write('\n');
				for (String s : allPkgName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------clsName----------------");
				fo.write('\n');
				for (String s : allClsName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------methodName----------------");
				fo.write('\n');
				for (String s : allMethodName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------fieldName----------------");
				fo.write('\n');
				for (String s : allFieldName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------classSig----------------");
				fo.write('\n');
				for (String s : allClsSig) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------externalMethodName----------------");
				fo.write('\n');
				for (String s : allExternalMethodName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------externalFieldName----------------");
				fo.write('\n');
				for (String s : allExternalFieldName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------externalClsName----------------");
				fo.write('\n');
				for (String s : allExternalClsName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------externalPkgName----------------");
				fo.write('\n');
				for (String s : allExternalPkgName) {
					fo.write(s);
					fo.write('\n');
				}
				fo.write("----------------externalClsSig----------------");
				fo.write('\n');
				for (String s : allExternalClsSig) {
					
					fo.write(s);
					fo.write('\n');
				}
				
				fo.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(path);
			System.out.println(total_classes);
			System.out.println(total_dexes_size);
			System.out.println("end");
		} else if (path.endsWith(".dex")) {
			// List<String> allStringConstant = new ArrayList<String>();
			// analyze(path, allStringConstant);
		} else {
			System.out.println("Unkown file format(only dex or apk");
		}
	}

	public static List<String> unzip(String path, Set<String> allFiles) {
		List<String> ret = new ArrayList<String>();
		try {
			ZipInputStream zis = new ZipInputStream(new FileInputStream(path));
			ZipEntry ze;
			Path p = Paths.get(path);
			String apkName = p.getFileName().toString();
			String apkFolder = p.getParent().toString();
			apkName = apkName.substring(0, apkName.length() - 4);
			ze = zis.getNextEntry();
			byte[] buffer = new byte[1024];
			int i = 0;
			while (ze != null) {

				String filename = ze.getName();
				allFiles.add(filename);
				// System.out.println(filename);
				if (filename.endsWith(".dex")) {
					String newFilename = Paths.get(filename).getFileName().toString();
					newFilename = newFilename.substring(0, newFilename.length() - 4) + i + ".dex";
					// System.out.println(newFilename);
					i++;
					// System.out.println(apkName + "-" + filename);
					// File newFile = new File(apkName +"-"+ filename);
					FileOutputStream fos = new FileOutputStream(
							apkFolder + File.separator + apkName + "-" + newFilename);
					int len;
					while ((len = zis.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					}

					fos.close();
					ret.add(apkFolder + File.separator + apkName + "-" + newFilename);
				}
				ze = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	public static int analyze(String path, Set<String> allStringConstant, Set<String> allClsName,
			Set<String> allMethodName, Set<String> allFieldName, Set<String> allPkgName, 
			Set<String> allClassSig,
			Set<String> allExternalMethodName, Set<String> allExternalFieldName, 
			Set<String> allExternalClassName, Set<String> allExternalPkgName,
			Set<String> allExternalClsSig) {
		Set<String> allTypeAndProto = new HashSet<String>();
		int ret = 0;
		RandomAccessFile fn;
		try {
			fn = new RandomAccessFile(path, "rw");
			DexData dexData = new DexData(fn);
			dexData.load();
			for(String s : dexData.getAllTypeAndProto()){
//				System.out.println(s);
				allTypeAndProto.add(s);
			}
			for (String s : dexData.getAllExernalMethodName()) {
				allExternalMethodName.add(s);
			}
			for (String s : dexData.getAllExternalFieldName()) {
				allExternalFieldName.add(s);
			}
			for(String s: dexData.getAllExernalClassesName()){
				allExternalClassName.add(s);
			}
			for(String s: dexData.getAllExternalPackageName()){
				allExternalPkgName.add(s);
			}
			for(String s: dexData.getAllExternalClassSig()){
				allExternalClsSig.add(s);
			}
			for (String s : dexData.getAllClassesName()) {
				if(allExternalClassName.contains(s)){
					continue;
				}
				allClsName.add(s);
			}
			for (String s : dexData.getAllFieldName()) {
				if(allExternalFieldName.contains(s)){
					continue;
				}
				allFieldName.add(s);
			}
			for (String s : dexData.getAllMethodName()) {
				if(allExternalMethodName.contains(s)){
					continue;
				}
				
				allMethodName.add(s);
			}
			for (String s : dexData.getAllPackageName()) {
				if(allExternalPkgName.contains(s)){
					continue;
				}
				allPkgName.add(s);
			}
			for (String s : dexData.getAllClassSig()) {
				allClassSig.add(s);
			}
		
			for (String s : dexData.mStrings) {
				if(allExternalClsSig.contains(s)){
					continue;
				}
				if (allClassSig.contains(s)) {
					continue;
				}
				if (allFieldName.contains(s)) {
					continue;
				}
				if (allMethodName.contains(s)) {
					continue;
				}
				if (allExternalFieldName.contains(s)) {
					continue;
				}
				if (allExternalMethodName.contains(s)) {
					continue;
				}
				if(allTypeAndProto.contains(s)){
					continue;
				}
				allStringConstant.add(s);
				// System.out.println(s);
			}
			ret = dexData.mClassDefs.length;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

}
