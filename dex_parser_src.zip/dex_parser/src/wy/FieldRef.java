package wy;

public class FieldRef {
    private String mDeclClass, mFieldType, mFieldName;
    /**
     * Initializes a new field reference.
     */
    public FieldRef(String declClass, String fieldType, String fieldName) {
        mDeclClass = declClass;
        mFieldType = fieldType;
        mFieldName = fieldName;
    }
    /**
     * Gets the name of the field's declaring class.
     */
    public String getDeclClassName() {
        return mDeclClass;
    }
    /**
     * Gets the type name.  Examples: "Ljava/lang/String;", "[I".
     */
    public String getTypeName() {
        return mFieldType;
    }
    /**
     * Gets the field name.
     */
    public String getName() {
        return mFieldName;
    }
}
